<div class="control-group">
    <label class="control-label">{title}</label>
    <div class="controls">
        {options}
        <label class="radio">
            <input type="radio" name="{name}" value="{value}" {checked}/>{label}
        </label>
        {/options}
        <small>{explain}</small>
    </div>
</div>

