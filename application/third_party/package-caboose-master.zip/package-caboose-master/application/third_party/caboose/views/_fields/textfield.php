<div><label for="{name}">{label}</label>
	<input type="text" id="{name}" name="{name}" value="{value}" maxLength="{maxlen}" size="size"  title="{explain}" {disabled}/>
</div>