<div><label for="{name}">{label}</label>
	<textarea id="{name}" name="{name}" value="{value}" rows="{rows}" cols="{size}"  title="{explain}" {disabled}>{value}</textarea>
</div>