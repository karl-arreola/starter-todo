<div class="control-group">
    <label class="control-label" for="{name}">{label}<br/>
    </label>
    <div class="controls">
        <textarea id="{name}" name="{name}" value="{value}" maxLength="{maxlen}" rows="{rows}" size="{size}" {disabled}>{value}</textarea>
    <br/><small><em>{explain}</em></small></div>
</div>
