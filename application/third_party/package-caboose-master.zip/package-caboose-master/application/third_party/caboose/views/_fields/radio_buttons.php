<div><label>{title}</label>
	{options}
		<input type="radio" name="{name}" value="{value}"  title="{explain}" {checked}/> {label}
	{/options}
</div>